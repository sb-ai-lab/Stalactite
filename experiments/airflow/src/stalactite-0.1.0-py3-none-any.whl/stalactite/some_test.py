import pickle
import torch

a = torch.tensor([[1, 2, 3], [0, 1, 2]])
print(a.shape)
print(a.unique())
print(a.unique().shape[0])


with open("../experiments/tmp.pkl", "rb") as f:
    data = pickle.load(f)

print(data.shape[1])
