import torch
torch.manual_seed(0)


single = False

y = torch.tensor([0]).reshape(1, 1)
criterion = torch.nn.BCEWithLogitsLoss()

if single:
    X1 = torch.tensor([[-0.5, 1, 0.8]])
    X2 = torch.tensor([-0.3])

    linear1 = torch.nn.Linear(3, 1, bias=False)
    linear2 = torch.nn.Linear(1, 1, bias=False)

    linear1.weight.data = torch.full((1, 3), 0.5)
    linear2.weight.data = torch.full((1, 1), 0.5)

    print("init weigths1", linear1.weight.data)
    print("init weigths2", linear2.weight.data)
    # w1 = torch.tensor([1, 0.5, 0.3], requires_grad=True)
    # w2 = torch.tensor([0.7], requires_grad=True)

    # preds1 = torch.sum(w1 * X1)
    # preds2 = torch.sum(w2 * X2)
    preds1 = linear1(X1)
    preds2 = linear2(X2)

    print("preds1", preds1)
    print("preds2", preds2)

    predictions = preds1 + preds2
    print("predictions", predictions)

    loss = criterion(predictions, y.float())
    main_grad = torch.autograd.grad(loss, predictions, retain_graph=True)
    print("main grad", main_grad)

    loss.backward()
    print(loss)
    print("weigths grads")
    # print(w1.grad)
    # print(w2.grad)
    print(linear1.weight.grad)
    print(linear2.weight.grad)

# main grad (tensor([[0.6225]]),)
# tensor([[-0.3112,  0.6225,  0.4980]])
# tensor([[-0.1867]])

else:
    X = torch.tensor([[-0.5, 1, 0.8, -0.3]])
    linear = torch.nn.Linear(4, 1, bias=False)
    linear.weight.data = torch.full((1, 4), 0.5)


    # w = torch.tensor([1, 0.5, 0.3, 0.7], requires_grad=True)
    # predictions = torch.sum(w * X)
    predictions = linear(X)
    loss = criterion(predictions, y.float())
    main_grad = torch.autograd.grad(loss, predictions, retain_graph=True)
    print("main grad", main_grad)
    # print("w", torch.autograd.grad(predictions, w, retain_graph=True, grad_outputs=main_grad))
    loss.backward()
    print(loss)
    print("weigths grads")
    print(linear.weight.grad)




# tensor(0.7083, grad_fn=<BinaryCrossEntropyWithLogitsBackward0>)
# weigths grads
# tensor([-0.2537,  0.5075,  0.4060])
# tensor([-0.1522])


# print()
# print(predictions.grad)
# print("preds 1 2 grads")
# print(preds1.grad)
# print(preds2.grad)




# preds1 = torch.tensor(preds1, requires_grad=True)
# preds2 = torch.tensor(preds2, requires_grad=True)

# preds1 = torch.tensor([-0.5, 1, 0.8], requires_grad=True)
# preds2 = torch.tensor([-0.3, 0, 2.3], requires_grad=True)
# preds3 = torch.tensor([1.2], requires_grad=True)




# predictions = torch.sum(torch.stack([preds1, preds2], dim=1), dim=1)
# predictions = torch.tensor(predictions, requires_grad=True) # мы так обрубаем граф
# loss = criterion(torch.squeeze(predictions), y.float())

# loss1 = criterion(torch.squeeze(preds1), y.float())
# loss2 = criterion(torch.squeeze(preds2), y.float())



# print("w1 grad", torch.autograd.grad(predictions, w1, retain_graph=True, grad_outputs=main_grad))
# print("w2 grad", torch.autograd.grad(predictions, w2, retain_graph=True, grad_outputs=main_grad))

# w1 grad (tensor([-0.2537,  0.5075,  0.4060]),)
# w2 grad (tensor([-0.1522]),)

# print(torch.autograd.grad(loss,e preds1, retain_graph=True))
# print(torch.autograd.grad(loss, preds2, retain_graph=True))

# print(torch.autograd.grad(loss, preds2))



# print(torch.autograd.grad(loss, preds1, retain_graph=True))
# print(torch.autograd.grad(loss, preds2, retain_graph=True))
# print(torch.autograd.grad(loss, preds3, retain_graph=True))


